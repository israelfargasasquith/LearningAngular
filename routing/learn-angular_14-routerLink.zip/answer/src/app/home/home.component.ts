import {Component} from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <div>Home Page</div>
  `,
})
export class HomeComponent {}
